package zone.god.blogprojectbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogProjectBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
