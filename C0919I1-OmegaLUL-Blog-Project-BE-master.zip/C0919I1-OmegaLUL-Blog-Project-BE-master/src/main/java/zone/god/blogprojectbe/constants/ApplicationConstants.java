package zone.god.blogprojectbe.constants;

public class ApplicationConstants {
    public static final String BASE_PACKAGE_NAME = "zone.god.blogprojectbe";
}
