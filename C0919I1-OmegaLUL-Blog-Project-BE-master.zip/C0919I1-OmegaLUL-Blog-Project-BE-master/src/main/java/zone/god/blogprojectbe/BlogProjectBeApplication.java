package zone.god.blogprojectbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogProjectBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BlogProjectBeApplication.class, args);
    }

}
