package zone.god.blogprojectbe.model;

public enum RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
