export interface Image {
  id: number;
  pic: any;
  imgURL: string;
}
