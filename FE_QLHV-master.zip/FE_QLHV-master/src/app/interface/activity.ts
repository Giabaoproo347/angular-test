export interface Activity {
  id: number;
  name: string;
}
