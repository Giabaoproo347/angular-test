import {Syllabus} from './syllabus';

export interface Objective {
  id: number;
  name: string;
  syllabus?: any;
}
