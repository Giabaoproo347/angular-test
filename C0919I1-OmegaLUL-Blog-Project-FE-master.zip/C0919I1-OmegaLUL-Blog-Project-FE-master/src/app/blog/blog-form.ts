export class BlogForm {
  id: number;
  tittle: string;
  description: string;
  thumbnail: string;
  tagList: number[];
  content: string;
}
