import { BlogForm } from './blog-form';

describe('BlogForm', () => {
  it('should create an instance', () => {
    expect(new BlogForm()).toBeTruthy();
  });
});
