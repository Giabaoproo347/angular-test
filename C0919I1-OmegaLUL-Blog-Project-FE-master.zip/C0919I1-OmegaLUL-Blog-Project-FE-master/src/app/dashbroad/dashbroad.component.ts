import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashbroad',
  templateUrl: './dashbroad.component.html',
  styleUrls: ['./dashbroad.component.scss']
})
export class DashbroadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
