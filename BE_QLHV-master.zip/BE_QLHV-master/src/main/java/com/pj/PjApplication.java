package com.pj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PjApplication {

    public static void main(String[] args) {
        SpringApplication.run(PjApplication.class, args);
    }

}
