package com.pj.services;

import com.pj.models.Syllabus;

public interface ISyllabusService extends GeneralService<Syllabus> {
}
