package com.pj.services;

import com.pj.models.Activity;

public interface IActivityService extends GeneralService<Activity> {
}
