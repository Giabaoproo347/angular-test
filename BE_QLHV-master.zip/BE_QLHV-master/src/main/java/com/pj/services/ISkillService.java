package com.pj.services;

import com.pj.models.Skill;

public interface ISkillService extends GeneralService<Skill> {
}
