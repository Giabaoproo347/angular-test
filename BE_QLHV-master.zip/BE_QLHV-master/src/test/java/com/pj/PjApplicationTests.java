package com.pj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PjApplicationTests {

    @Test
    void contextLoads() {
    }

}
